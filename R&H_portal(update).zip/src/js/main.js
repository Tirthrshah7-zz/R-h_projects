//header scroll
var scrollpos = window.scrollY;
var header = document.querySelector(".header");
window.addEventListener('scroll', function () {
    scrollpos = window.scrollY;
    if (scrollpos > 50) {
        header.classList.add("header-bg");
    }
    else {
        header.classList.remove("header-bg");
    }
});



// sidebar collaspe

var close = document.querySelectorAll(".ham-toggle");
var body = document.querySelector("body");
close.forEach(sidebar => {
    sidebar.addEventListener('click', () => {
        body.classList.toggle("side_collaspe");
    })
})





// scroll section
const sections = document.querySelectorAll('.raine-tabs[id]')

function scrollActive() {
    const scrollY = window.pageYOffset

    sections.forEach(current => {
        const sectionHeight = current.offsetHeight
        const sectionTop = current.offsetTop - 50;
        sectionId = current.getAttribute('id')

        if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
            document.querySelector('.nav__menu a[href*=' + sectionId + ']').classList.add('active')
        } else {
            document.querySelector('.nav__menu a[href*=' + sectionId + ']').classList.remove('active')
        }
    })
}
window.addEventListener('scroll', scrollActive)

